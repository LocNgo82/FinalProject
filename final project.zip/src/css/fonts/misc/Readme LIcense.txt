THIS FONT IS DEMO ONLY
Free for personal used
any donation are very appreciated.
PayPal account for donation : https://paypal.me/abahrozi


--------------------------------------------------------

ENGLISH:

Be very careful and take the time to read any and all documentation before deciding
to use a font commercially. Ignorance is not an excuse for breaking the law.

By installing or using this font, you are hereby agree
to this Product Usage Agreement:

1. This font is ONLY FOR PERSONAL USE
2. NO COMMERCIAL USE ALLOWED
3. You are REQUIRES A LICENSE for PROMOTIONAL or COMMERCIAL USE
4. CONTACT ME before any Promotional or Commercial Use

For special commercial use:
https://twinletter.com/

------------------------------------------------

INDONESIA:

Berhati-hatilah dan luangkan waktu untuk membaca Syarat & Ketentuan dibawah,
sebelum memutuskan untuk menggunakan font secara komersial.
Ketidaktahuan bukanlah alasan untuk suatu pelanggaran hukum.

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use", atau untuk keperluan
yang sifatnya tidak komersil, alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font saya. Baik itu untuk Perorangan/Individual, Agensi Desain Grafis, Percetakan, atau Perusahaan/Korporasi.

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk keperluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk ( baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.   

3. Menggunakan font ini untuk keperluan/kepentingan komersial, apapun bentuknya TANPA IZIN atau TANPA MEMBELI LISENSI font terlebih dahulu dari saya, selaku Pencipta
dan/atau Pemegang Hak Cipta font, akan dikenakan biaya EXTENDED LICENSE atau 100 kali harga dari harga Lisensi Standard, atau sesuai dengan ketentuan yang telah diatur dalam Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:

https://twinletter.com/

Thanks
