import React from 'react';
// This is the home page for the final project
export const Home = () => {
    return (    
    <div><h2>This is the final project for Front End Bootcamp</h2>    
    </div>    
    );
}
